package com.example.cal_staff.button;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class second extends AppCompatActivity {

    public ImageButton image1;

    public void init4 () {
        ImageButton image1 = (ImageButton) findViewById(R.id.image1);
        // final Context context = this;
        image1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(second.this, Pooltype.class);
                startActivity(intent);
            }
        });
    }
        public ImageButton image2;

         public void init5 () {
             ImageButton image2 = (ImageButton) findViewById(R.id.image2);
             // final Context context = this;
             image2.setOnClickListener(new View.OnClickListener() {
                 @Override
                 public void onClick(View v) {
                     Intent intent = new Intent(second.this, CollectData.class);
                     startActivity(intent);
                 }
             });
         }
        public ImageButton image3;

    public void init6 () {
        ImageButton image3 = (ImageButton) findViewById(R.id.image3);
        // final Context context = this;
        image3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(second.this, DataAnalysis.class);
                startActivity(intent);
            }
        });
    }
        public ImageButton image4;

    public void init7 (){
        ImageButton image4 = (ImageButton) findViewById(R.id.image4);
        // final Context context = this;
        image4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(second.this, Database.class);
                startActivity(intent);
            }
        });
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        init4();
        init5();
        init6();
        init7();



    }
    }
